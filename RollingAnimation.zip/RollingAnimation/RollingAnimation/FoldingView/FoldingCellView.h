//
//  FoldingCellView.h
//  POPAnimation01
//
//  Created by hebe on 17/10/6.
//  Copyright © 2017年 liangbin. All rights reserved.
//

#import "BasicRollingView.h"

@interface FoldingCellView : BasicRollingView

@end
