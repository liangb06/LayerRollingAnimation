//
//  FoldingViewAnimationContoller.h
//  POPAnimation01
//
//  Created by hebe on 17/10/6.
//  Copyright © 2017年 liangbin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FoldingViewAnimationContoller : NSObject

-(void)unfoldingset;
-(void)foldingset;

-(NSArray*) getAnimArray;
@end
